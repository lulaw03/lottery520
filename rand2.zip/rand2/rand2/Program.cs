﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace rand2
{
    class Program
    {
        static void Main(string[] args)
        {
            // 設定文字顏色為黃色,背景為灰色
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.BackgroundColor = ConsoleColor.DarkGray;

            // 輸入產生幾組亂數
            Console.Write("輸入想要產生幾組亂數:");
            string number = Console.ReadLine();
            
            // 產生亂數物件
            Random rand = new Random();

            // 紀錄產生亂數的次數
            int count = 0;

            // 設定用戶輸入的次數為最大值
            int max = int.Parse(number);
           
            // 當次數達到最大值時，停止執行迴圈
            while (count < max)
            {

                // 用亂數物件產生六個亂數///會重複號碼
                int r1 = rand.Next(1, 43);
                int r2 = rand.Next(1, 43);
                int r3 = rand.Next(1, 43);
                int r4 = rand.Next(1, 43);
                int r5 = rand.Next(1, 43);
                int r6 = rand.Next(1, 43);

                // 設定文字顏色為藍綠色
                Console.ForegroundColor = ConsoleColor.Cyan;

                // 強制不重複
                if (r1 != r2 && r1 != r3 && r1 != r4 && r1 != r5 && r1 != r6 && r2 != r3 && r2 != r4 && r2 != r5 && r2 != r6 && r3 != r4 && r3 != r5 && r3 != r6 && r4 != r5 && r5 != r6)
                {
                    count += 1;//次數加一
                    Console.WriteLine("╔═════════════════════════════╗");
                    Console.WriteLine("第" + "[" + count + "]" + "組" + " {0:00} {1:00} {2:00} {3:00} {4:00} {5:00}", r1, r2, r3, r4, r5, r6); // 顯示亂數/// {0:00} 冒號後面的位數表示顯示的位數
                    Console.WriteLine("╚═════════════════════════════╝");
                }

                // 讓使用者期待簽號
                Thread.Sleep(500);
            }
            
            //停止
            Console.ReadKey();
        }
    }
}
